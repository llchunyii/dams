USE DAMS;
GO

-- Masking
-- Mask Name: first letter + XXXXX
ALTER TABLE [User]
ALTER COLUMN Name ADD MASKED WITH (FUNCTION = 'partial(1,"XXXXX",0)');
ALTER TABLE Supplier
ALTER COLUMN Name ADD MASKED WITH (FUNCTION = 'partial(1,"XXXXX",0)');

-- Mask Email Addresses: first letter + XXX @ XXX + .com
ALTER TABLE [User]
ALTER COLUMN Email ADD MASKED WITH (FUNCTION = 'email()');
ALTER TABLE Supplier
ALTER COLUMN Email ADD MASKED WITH (FUNCTION = 'email()');
GO

-- Mask Phone Numbers: first 3 digits + XXXXXX + last 2 digits
ALTER TABLE [User]
ALTER COLUMN Phone ADD MASKED WITH (FUNCTION = 'partial(3,"XXXXXX",2)');
ALTER TABLE Supplier
ALTER COLUMN Phone ADD MASKED WITH (FUNCTION = 'partial(3,"XXXXXX",2)');
GO

-- Mask Addresses: XXXX (completely hidden)
ALTER TABLE [User]
ALTER COLUMN Address ADD MASKED WITH (FUNCTION = 'default()');
ALTER TABLE Supplier
ALTER COLUMN Address ADD MASKED WITH (FUNCTION = 'default()');
GO



-- Grant UNMASK Permission 


-- Verify Masking
-- Check Dynamic Masked Columns
SELECT  
    tbl.name AS TableName,
    c.name AS ColumnName,
    c.is_masked,
    c.masking_function
FROM sys.masked_columns AS c
JOIN sys.tables AS tbl
    ON c.[object_id] = tbl.[object_id];

-- Check role memberships with UNMASK permission
SELECT 
    dp1.name AS PrincipalName,
    dp1.type_desc AS PrincipalType,
    dp2.name AS RoleName,
    dp2.type_desc AS RoleType,
	perm.class_desc AS PermissionClass,
	OBJECT_NAME(perm.major_id) AS ObjectName,
    perm.permission_name,
    perm.state_desc AS PermissionState
FROM sys.database_permissions perm
LEFT JOIN sys.database_principals dp2 
    ON perm.grantee_principal_id = dp2.principal_id
LEFT JOIN sys.database_role_members drm
    ON dp2.principal_id = drm.role_principal_id
LEFT JOIN sys.database_principals dp1
    ON drm.member_principal_id = dp1.principal_id
WHERE perm.permission_name = 'UNMASK';
