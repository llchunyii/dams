USE DAMS;
GO

-- Table to track DDL changes 
CREATE TABLE DDLAuditLog (
    AuditID INT IDENTITY(1,1) PRIMARY KEY,
    EventTime DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    UserName SYSNAME NOT NULL DEFAULT USER_NAME(),  
	LoginName NVARCHAR(256),
	SchemaName SYSNAME NULL,
    ObjectName SYSNAME NULL,		
    ObjectType NVARCHAR(60) NULL,		
    EventType NVARCHAR(100) NOT NULL,   
    SQLCommand NVARCHAR(MAX) NULL,        
    Prevented BIT NOT NULL DEFAULT 0  
);
GO


-- TRIGGER: Audit All DDL Schema Changes
CREATE OR ALTER TRIGGER trg_DDLChangeLog
ON DATABASE
FOR DDL_DATABASE_LEVEL_EVENTS
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        DECLARE @EventData XML = EVENTDATA();

        DECLARE
            @LoginName   NVARCHAR(256),
            @SchemaName  SYSNAME,
            @ObjectName  SYSNAME,
            @ObjectType  NVARCHAR(60),
            @EventType   NVARCHAR(100),
            @SQLCommand  NVARCHAR(MAX);

        -- Extract details
        SET @LoginName  = @EventData.value('(/EVENT_INSTANCE/LoginName)[1]', 'NVARCHAR(256)');
        SET @SchemaName = @EventData.value('(/EVENT_INSTANCE/SchemaName)[1]', 'SYSNAME');
        SET @ObjectName = @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'SYSNAME');
        SET @ObjectType = @EventData.value('(/EVENT_INSTANCE/ObjectType)[1]', 'NVARCHAR(60)');
        SET @EventType  = @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'NVARCHAR(100)');
        SET @SQLCommand = @EventData.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'NVARCHAR(MAX)');

        -- Log ALL DDL changes for security audit
		BEGIN
            INSERT INTO DDLAuditLog (LoginName, SchemaName, ObjectName, ObjectType, EventType, SqlCommand)
            VALUES (@LoginName, @SchemaName, @ObjectName, @ObjectType, @EventType, @SQLCommand);
        END  
    END TRY
    BEGIN CATCH
        DECLARE @Err NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT CONCAT('DDL Audit Error: ', @Err);
    END CATCH
END;
GO


-- TRIGGER: Protect Critical Table 
CREATE OR ALTER TRIGGER trg_PreventCriticalTableDrop
ON DATABASE
FOR DROP_TABLE
AS
BEGIN
    SET NOCOUNT ON;
    
	DECLARE @EventData XML = EVENTDATA();

    DECLARE
        @LoginName   NVARCHAR(256),
        @SchemaName  SYSNAME,
        @TableName  SYSNAME,
        @ObjectType  NVARCHAR(60),
        @EventType   NVARCHAR(100),
        @SQLCommand  NVARCHAR(MAX);

    -- Extract details
    SET @LoginName  = @EventData.value('(/EVENT_INSTANCE/LoginName)[1]', 'NVARCHAR(256)');
    SET @SchemaName = @EventData.value('(/EVENT_INSTANCE/SchemaName)[1]', 'SYSNAME');
    SET @TableName = @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'SYSNAME');
    SET @ObjectType = @EventData.value('(/EVENT_INSTANCE/ObjectType)[1]', 'NVARCHAR(60)');
    SET @EventType  = @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'NVARCHAR(100)');
    SET @SQLCommand = @EventData.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'NVARCHAR(MAX)');

    -- Protected tables (critical system tables)
    IF @TableName IN ('User', 'Agents', 'Sales', 'Commission', 'Products', 'Supplier', 'Campaign', 
					'Promotion', 'SalesItem', 'PromotionProduct', 'StockIn', 'Inventory')
    BEGIN
		-- Check if sysadmin
		IF IS_SRVROLEMEMBER('sysadmin') = 0
		BEGIN
			-- Log the attempted action
			INSERT INTO DDLAuditLog (LoginName, SchemaName, ObjectName, ObjectType, EventType, SqlCommand, Prevented)
			VALUES (@LoginName, @SchemaName, @TableName, 'TABLE', 'DROP_TABLE_PREVENTED', @SQLCommand, 1);
        
			-- BLOCK THE ACTION
			RAISERROR('Cannot drop critical business table [%s]. This table contains essential operational data.', 16, 1, @TableName);
			ROLLBACK TRANSACTION;
			RETURN;
		END;
    END

	-- Allowed drop (either not protected OR sysadmin)
    BEGIN
		INSERT INTO DDLAuditLog (LoginName, SchemaName, ObjectName, ObjectType, EventType, SqlCommand, Prevented)
        VALUES (@LoginName, @SchemaName, @TableName, 'TABLE', 'DROP_TABLE', @SQLCommand, 0);
    END
END
GO
