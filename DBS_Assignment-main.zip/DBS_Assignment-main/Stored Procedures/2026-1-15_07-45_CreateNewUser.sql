USE DAMS;
GO
CREATE OR ALTER PROCEDURE CreateNewUser(
	@Username NVARCHAR(50),
	@Name NVARCHAR(50),
	@Phone NVARCHAR(20),
	@Email NVARCHAR(100),
	@Password NVARCHAR(100),
	@Address NVARCHAR(500),
	@UserType NVARCHAR(100),
	@NewUserID INT OUTPUT
)
AS 
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRANSACTION;

	    DECLARE @PasswordSalt VARBINARY(16);
	    DECLARE @PasswordHash VARBINARY(64);

		SET @PasswordSalt = CRYPT_GEN_RANDOM(16);
		SET @PasswordHash = HASHBYTES('SHA2_256', CONVERT(VARBINARY(MAX), @Password) + @PasswordSalt);

		INSERT INTO [User] (
			[Username], 
			[Password], 
			[PasswordSalt],
			[Address],
			[UserType],
			[Name],
			[Email],
			[Phone]
			)
		VALUES(
			@Username, 
			@PasswordHash,
			@PasswordSalt,
			@Address,
			@UserType,
			@Name,
			@Email,
			@Phone
		);
		SET @NewUserID = SCOPE_IDENTITY();
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		PRINT 'Error: ' + ERROR_MESSAGE();
		THROW;
	END CATCH
END