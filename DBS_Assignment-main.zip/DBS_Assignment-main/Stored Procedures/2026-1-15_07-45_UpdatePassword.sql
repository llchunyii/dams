USE DAMS;
GO

CREATE OR ALTER PROCEDURE UpdateUserPassword
	@UserID INT,
	@Password NVARCHAR(100)
AS
BEGIN;
	SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRANSACTION;
			DECLARE @PasswordSalt VARBINARY(16);
			DECLARE @PasswordHash VARBINARY(64);

			SET @PasswordSalt = CRYPT_GEN_RANDOM(16);
			SET @PasswordHash = HASHBYTES('SHA2_256', CONVERT(VARBINARY(MAX), @Password) + @PasswordSalt);

			UPDATE [dbo].[User]
			SET 
				[Password] = @PasswordHash,
				[PasswordSalt] = @PasswordSalt

			WHERE UserID = @UserID;

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION;
		PRINT 'Error occured during password update ' + ERROR_MESSAGE();
		THROW;
	END CATCH;
	

END;