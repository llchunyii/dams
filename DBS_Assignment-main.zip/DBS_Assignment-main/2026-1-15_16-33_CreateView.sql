USE DAMS; 
Go 

---------------- Marketing Team ------------------

-- View 1: Active Campaigns with Promotion Details (Marketing team: manage ongoing campaigns)
Create view Marketing_Campaigns as 
Select 
	c.CampaignID,
    c.Name AS CampaignName,
    c.StartDate,
    c.EndDate,
    DATEDIFF(DAY, GETDATE(), c.EndDate) AS DaysRemaining,
    COUNT(p.PromotionID) AS TotalPromotions,
    CASE 
        WHEN GETDATE() BETWEEN c.StartDate AND c.EndDate THEN 'Active'
        WHEN GETDATE() < c.StartDate THEN 'Upcoming'
        ELSE 'Expired'
    END AS CampaignStatus
FROM Campaign c
LEFT JOIN Promotion p ON c.CampaignID = p.CampaignID
GROUP BY c.CampaignID, c.Name, c.StartDate, c.EndDate;
Go 
--Select* from Marketing_Campaigns

-- View 2: Promotion Performance Summary (Marketing team: analyze promotion effectiveness)
CREATE VIEW Marketing_PromotionPerformance AS
SELECT 
    pr.PromotionID,
    pr.Name AS PromotionName,
    pr.DiscountRate,
    c.Name AS CampaignName,
    c.StartDate,
    c.EndDate,
    COUNT(DISTINCT pp.PromotionProductID) AS ProductsInPromotion,
    COUNT(DISTINCT si.SalesItemID) AS TotalItemsSold,
    ISNULL(SUM(si.Subtotal), 0) AS TotalRevenue
FROM Promotion pr
INNER JOIN Campaign c ON pr.CampaignID = c.CampaignID
LEFT JOIN PromotionProduct pp ON pr.PromotionID = pp.PromotionID
LEFT JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
GROUP BY pr.PromotionID, pr.Name, pr.DiscountRate, c.Name, c.StartDate, c.EndDate;
GO
--Select* from Marketing_PromotionPerformance

-- View 3: Product Catalog for Marketing (Marketing team: product information without supplier details)
CREATE VIEW Marketing_ProductCatalog AS
SELECT 
    p.ProductID,
    p.Name AS ProductName,
    p.Description,
    p.Price,
    p.Status,
    s.Company AS SupplierCompany,
    COUNT(DISTINCT pp.PromotionProductID) AS TimesPromoted,
    p.CreatedAt
FROM Products p
INNER JOIN Supplier s ON p.SupplierID = s.SupplierID
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID AND pp.PromotionID IS NOT NULL
GROUP BY p.ProductID, p.Name, p.Description, p.Price, p.Status, s.Company, p.CreatedAt;
GO
--Select* from Marketing_ProductCatalog

-- View 4: Agent Performance for Marketing Campaigns (Marketing team: identify top-performing agents for targeted campaigns)
CREATE VIEW Marketing_AgentPerformance AS
SELECT 
    a.AgentID,
    u.Name AS AgentName,
    a.AgentType,
    LEFT(u.Email, 3) + '***@' + RIGHT(u.Email, CHARINDEX('@', REVERSE(u.Email)) - 1) AS MaskedEmail,
    COUNT(DISTINCT s.SalesID) AS TotalSales,
    SUM(s.TotalAmount) AS TotalRevenue,
    AVG(s.TotalAmount) AS AverageSaleAmount,
    MAX(s.SalesDate) AS LastSaleDate
FROM Agents a
INNER JOIN [User] u ON a.AgentID = u.UserID
LEFT JOIN Sales s ON a.AgentID = s.AgentID
WHERE a.Status = 'Active'
GROUP BY a.AgentID, u.Name, a.AgentType, u.Email;
GO
-- Select* from Marketing_AgentPerformance

----------------- Analytics Team ----------------------

-- View 1: Sales Trend Analysis (Analytics team: sales forecasting and trend analysis)
CREATE VIEW Analytics_SalesTrend AS
SELECT 
    YEAR(s.SalesDate) AS SalesYear,
    MONTH(s.SalesDate) AS SalesMonth,
    a.AgentType,
    s.Region, 
    COUNT(s.SalesID) AS TotalTransactions,
    SUM(s.TotalAmount) AS TotalRevenue,
    AVG(s.TotalAmount) AS AverageOrderValue
FROM Sales s
LEFT JOIN Agents a ON s.AgentID = a.AgentID
GROUP BY YEAR(s.SalesDate), MONTH(s.SalesDate), a.AgentType, s.Region;
GO
-- Select* from Analytics_SalesTrend

-- View 2: Product Performance Analytics (Analytics team: identify best products)
create view Analytics_ProductPerformance as
select
    p.ProductID,
    p.Name AS ProductName,
    p.Price AS CurrentPrice,
    p.Status,
    s.Company AS SupplierCompany,
    -- Stock metrics
    ISNULL(SUM(st.Quantity), 0) AS TotalStockIn,
    ISNULL(SUM(st.TotalCost), 0) AS TotalStockInCost,
    -- Sales metrics
    ISNULL(SUM(si.Quantity), 0) AS TotalUnitsSold,
    ISNULL(SUM(si.Subtotal), 0) AS TotalRevenue,
    -- Performance metrics
    CASE 
        WHEN ISNULL(SUM(si.Quantity), 0) > 100 THEN 'High Performer'
        WHEN ISNULL(SUM(si.Quantity), 0) BETWEEN 50 AND 100 THEN 'Medium Performer'
        WHEN ISNULL(SUM(si.Quantity), 0) BETWEEN 1 AND 49 THEN 'Low Performer'
        ELSE 'No Sales'
    END AS PerformanceCategory
FROM Products p
INNER JOIN Supplier s ON p.SupplierID = s.SupplierID
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID
LEFT JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
GROUP BY p.ProductID, p.Name, p.Price, p.Status, s.Company;
GO
--Select * from Analytics_ProductPerformance

-- View 3: Commission Analysis (Analytics team: analyze commission effectiveness)
CREATE VIEW Analytics_CommissionAnalysis As
select
    c.CommissionID,
    s.SalesID,
    a.AgentType,
    s.TotalAmount AS SalesAmount,
    c.CommissionRate,
    c.CommissionAmount,
    YEAR(s.SalesDate) AS Year,
    MONTH(s.SalesDate) AS Month,
    CAST((c.CommissionAmount / s.TotalAmount * 100) AS DECIMAL(5,2)) AS CommissionPercentage
FROM Commission c
INNER JOIN Sales s ON c.SalesID = s.SalesID
INNER JOIN Agents a ON s.AgentID = a.AgentID;
GO
--elect * from Analytics_CommissionAnalysis

-- View 4: Supplier Performance Metrics (Analytics team: supplier evaluation)
Create View Analytics_SupplierMetrics As
Select
    s.SupplierID,
    s.Name AS SupplierName,
    s.Company,
    LEFT(s.Email, 3) + '***' AS MaskedEmail,
    -- Product metrics
    COUNT(DISTINCT p.ProductID) AS TotalProducts,
    COUNT(DISTINCT CASE WHEN p.Status = 'Available' THEN p.ProductID END) AS AvailableProducts,
    -- Stock metrics
    ISNULL(SUM(st.Quantity), 0) AS TotalStockReceived,
    ISNULL(SUM(st.TotalCost), 0) AS TotalPurchaseValue,
    -- Sales performance
    ISNULL(SUM(si.Quantity), 0) AS TotalUnitsSold,
    ISNULL(SUM(si.Subtotal), 0) AS TotalRevenue
FROM Supplier s
LEFT JOIN Products p ON s.SupplierID = p.SupplierID
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID
LEFT JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
GROUP BY s.SupplierID, s.Name, s.Company, s.Email;
GO
--Select * From Analytics_SupplierMetrics

-- View 5: Customer Feedback Analysis (Analytics team: monitor service quality)
Create View Analytics_FeedbackSummary As
Select
    u.UserType,
    YEAR(f.CreatedAt) AS Year,
    MONTH(f.CreatedAt) AS Month,
    COUNT(f.FeedbackID) AS TotalFeedback,
    AVG(CAST(f.Rating AS FLOAT)) AS AverageRating,
    COUNT(CASE WHEN f.Rating >= 4 THEN 1 END) AS PositiveFeedback,
    COUNT(CASE WHEN f.Rating <= 2 THEN 1 END) AS NegativeFeedback,
    CAST(COUNT(CASE WHEN f.Rating >= 4 THEN 1 END) * 100.0 / COUNT(f.FeedbackID) AS DECIMAL(5,2)) AS SatisfactionRate
FROM Feedback f
INNER JOIN [User] u ON f.UserID = u.UserID
GROUP BY u.UserType, YEAR(f.CreatedAt), MONTH(f.CreatedAt);
GO
--Select * From Analytics_FeedbackSummary

-- View 6: Dashboard Summary (Business Overview)
Create VIEW Analytics_Dashboard AS
SELECT 
    'Current Month' AS Period,
    COUNT(DISTINCT s.SalesID) AS TotalSales,
    SUM(s.TotalAmount) AS TotalRevenue,
    COUNT(DISTINCT s.AgentID) AS ActiveAgents
FROM Sales s
WHERE MONTH(s.SalesDate) = MONTH(GETDATE())
    AND YEAR(s.SalesDate) = YEAR(GETDATE())
UNION ALL
SELECT 
    'Previous Month',
    COUNT(DISTINCT s.SalesID),
    SUM(s.TotalAmount),
    COUNT(DISTINCT s.AgentID)
FROM Sales s
WHERE MONTH(s.SalesDate) = MONTH(DATEADD(MONTH, -1, GETDATE()))
    AND YEAR(s.SalesDate) = YEAR(DATEADD(MONTH, -1, GETDATE()));
GO
-- Select* from Analytics_Dashboard


-- View 7: Top Performing Agents (For Rewarding? ) 
Create View Analytics_TopAgents As
SELECT TOP 100 PERCENT
    a.AgentID,
    u.Name AS AgentName,
    a.AgentType,
    COUNT(DISTINCT s.SalesID) AS TotalSales,
    SUM(s.TotalAmount) AS TotalRevenue,
    SUM(c.CommissionAmount) AS TotalCommission,
    AVG(s.TotalAmount) AS AverageSaleValue,
    MAX(s.SalesDate) AS LastSaleDate,
    DENSE_RANK() OVER (ORDER BY SUM(s.TotalAmount) DESC) AS RevenueRank
FROM Agents a
INNER JOIN [User] u ON a.AgentID = u.UserID
LEFT JOIN Sales s ON a.AgentID = s.AgentID
LEFT JOIN Commission c ON s.SalesID = c.SalesID
WHERE a.Status = 'Active'
GROUP BY a.AgentID, u.Name, a.AgentType
ORDER BY RevenueRank;
GO
--Select* from Analytics_TopAgents

------------ User Portal ----------------

-- View 1: User Profile (Portal: display agent profile)
-- Should be filtered by WHERE AgentID = CURRENT_USER in application layer
CREATE VIEW Portal_AgentProfile AS
SELECT 
    a.AgentID,
    u.Username,
    u.Name,
    -- Masked sensitive data
    LEFT(u.Email, 3) + '****@' + RIGHT(u.Email, CHARINDEX('@', REVERSE(u.Email)) - 1) AS MaskedEmail,
    LEFT(u.Phone, 3) + '-***-' + RIGHT(u.Phone, 4) AS MaskedPhone,
    LEFT(u.Address, 10) + '...' AS PartialAddress,
    a.AgentType,
    a.Status,
    a.CreatedAt AS MemberSince,
    -- Performance summary (visible to agent)
    COUNT(DISTINCT s.SalesID) AS TotalSales,
    ISNULL(SUM(s.TotalAmount), 0) AS TotalRevenue,
    ISNULL(SUM(c.CommissionAmount), 0) AS TotalCommissionEarned
FROM Agents a
INNER JOIN [User] u ON a.AgentID = u.UserID
LEFT JOIN Sales s ON a.AgentID = s.AgentID
LEFT JOIN Commission c ON s.SalesID = c.SalesID
WHERE a.Status = 'Active'
GROUP BY a.AgentID, u.Username, u.Name, u.Email, u.Phone, u.Address, a.AgentType, a.Status, a.CreatedAt;
GO
Select * From Portal_AgentProfile

-- View 2: Available Products with Current Promotions (Portal: display product catalog to agents)
create view Portal_ProductCatalog as
select
    p.ProductID,
    p.Name AS ProductName,
    p.Description,
    p.Price AS RegularPrice,
    p.Status,
    pr.PromotionID,
    pr.Name AS PromotionName,
    pr.DiscountRate,
   
    CASE -- only show promotion if got 
        WHEN pr.PromotionID IS NOT NULL THEN pp.SalesPrice
        ELSE NULL
    END AS PromotionalPrice,
    CASE -- only calculate when there is promotion 
        WHEN pr.PromotionID IS NOT NULL AND pp.SalesPrice IS NOT NULL 
        THEN p.Price - pp.SalesPrice
        ELSE 0
    END AS Savings,
    
    c.Name AS CampaignName,
    c.EndDate AS PromotionEndDate
    
FROM Products p
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID
LEFT JOIN Promotion pr ON pp.PromotionID = pr.PromotionID
LEFT JOIN Campaign c ON pr.CampaignID = c.CampaignID
WHERE p.Status = 'Available'
    AND (c.EndDate IS NULL OR c.EndDate >= GETDATE());
GO
--Select * from Portal_ProductCatalog

-- View 3: Agent Sales History (sales history to logged-in agent)
Create view Portal_AgentSalesHistory as
select
    s.SalesID,
    s.AgentID,
    s.SalesDate,
    s.TotalAmount,
    COUNT(DISTINCT si.SalesItemID) AS TotalItems,
    c.CommissionAmount,
    c.CommissionRate,
    -- Status indicator
    CASE 
        WHEN s.SalesDate >= DATEADD(DAY, -7, GETDATE()) THEN 'Recent'
        WHEN s.SalesDate >= DATEADD(DAY, -30, GETDATE()) THEN 'This Month'
        ELSE 'Historical'
    END AS SalesPeriod
FROM Sales s
LEFT JOIN SalesItem si ON s.SalesID = si.SalesID
LEFT JOIN Commission c ON s.SalesID = c.SalesID
GROUP BY s.SalesID, s.AgentID, s.SalesDate, s.TotalAmount, c.CommissionAmount, c.CommissionRate;
GO
--select* from Portal_AgentSalesHistory

-- View 4: Active Campaigns for Display (show current campaigns and promotions)
Create view Portal_ActiveCampaigns as
SELECT 
    c.CampaignID,
    c.Name AS CampaignName,
    c.StartDate,
    c.EndDate,
    COUNT(DISTINCT pr.PromotionID) AS TotalPromotions,
    COUNT(DISTINCT pp.ProductID) AS ProductsOnSale,
    DATEDIFF(DAY, GETDATE(), c.EndDate) AS DaysRemaining
FROM Campaign c
LEFT JOIN Promotion pr ON c.CampaignID = pr.CampaignID
LEFT JOIN PromotionProduct pp ON pr.PromotionID = pp.PromotionID
WHERE c.EndDate >= GETDATE()
GROUP BY c.CampaignID, c.Name, c.StartDate, c.EndDate;
GO
--Select* from Portal_ActiveCampaigns

-- View 5: User Management Overview (Account Monitoring) 
CREATE VIEW Portal_UserManagement AS
SELECT
    u.UserID,
    u.Username,
    u.UserType,
    u.Name,
    u.Email,
    u.Phone,
    u.CreatedAt,
    CASE 
        WHEN u.UserType = 'Agent' THEN a.Status
        WHEN u.UserType = 'Employee' THEN e.State
        ELSE 'N/A'
    END AS AccountStatus,
    CASE 
        WHEN u.UserType = 'Agent' THEN a.AgentType
        WHEN u.UserType = 'Employee' THEN d.Name
        ELSE 'N/A'
    END AS TypeOrDepartment,
    COUNT(al.ActivityID) AS TotalActivities,
    MAX(al.DoneAt) AS LastActivity
FROM dbo.[User] u
LEFT JOIN dbo.Agents a ON u.UserID = a.AgentID
LEFT JOIN dbo.Employee e ON u.UserID = e.EmployeeID
LEFT JOIN dbo.Department d ON e.DepartmentID = d.DepartmentID
LEFT JOIN dbo.ActivityLog al ON u.UserID = al.UserID
GROUP BY
    u.UserID, u.Username, u.UserType, u.Name, u.Email, u.Phone, u.CreatedAt,
    a.Status, e.State, a.AgentType, d.Name;
GO 
--Select* from Portal_UserManagement

-- View 6: System Activity Monitor (System Usage Patterns)
Create view Portal_ActivityMonitor As
SELECT 
    al.ActivityID,
    al.UserID,
    u.Username,
    u.UserType,
    al.ActivityType,
    al.DoneAt,
    DATENAME(WEEKDAY, al.DoneAt) AS DayOfWeek,
    DATEPART(HOUR, al.DoneAt) AS HourOfDay
FROM ActivityLog al
INNER JOIN [User] u ON al.UserID = u.UserID;
GO
--Select* from Portal_ActivityMonitor

----------------- Database Admins -------------------
-- View 1: View Database Inventory 
CREATE VIEW DBA_ObjectOverview AS
SELECT
    s.name        AS SchemaName,
    o.name        AS ObjectName,
    o.type_desc   AS DataType,
    o.create_date AS CreatedAt,
    o.modify_date AS LastModifiedAt
FROM sys.objects o
INNER JOIN sys.schemas s
    ON o.schema_id = s.schema_id
WHERE o.type IN ('U','V','P')   -- U=Table, V=View, P=Stored Procedure
  AND s.name NOT IN ('sys', 'INFORMATION_SCHEMA');
GO
Select* from DBA_ObjectOverview

-- View 2: Check Database Backup Status/History 
-- NEED TO RUN XIA BACKUP BECAUSE ME NULL 
CREATE VIEW DBA_BackupStatus AS
WITH bh AS (
    SELECT
        bs.database_name AS DatabaseName,
        MAX(CASE WHEN bs.type = 'D' THEN bs.backup_finish_date END) AS LastFullBackup,
        MAX(CASE WHEN bs.type = 'I' THEN bs.backup_finish_date END) AS LastDifferentialBackup,
        MAX(CASE WHEN bs.type = 'L' THEN bs.backup_finish_date END) AS LastLogBackup
    FROM msdb.dbo.backupset bs
    WHERE bs.database_name = 'DAMS'
    GROUP BY bs.database_name
)
SELECT
    DatabaseName,
    LastFullBackup,
    LastDifferentialBackup,
    LastLogBackup,
    CASE WHEN LastFullBackup IS NULL THEN 'MISSING' ELSE 'OK' END AS FullBackupStatus,
    CASE WHEN LastDifferentialBackup IS NULL THEN 'MISSING' ELSE 'OK' END AS DifferentialBackupStatus,
    CASE WHEN LastLogBackup IS NULL THEN 'MISSING' ELSE 'OK' END AS LogBackupStatus
FROM bh;
GO
Select* from DBA_BackupStatus

-- View 3: Database Statistics Summary (Quick Dashboard) 
Create view DBA_DatabaseStats as
select 
    'Total Users' AS Metric, 
    COUNT(*) AS Value,
    'Count' AS Unit
FROM [User]
UNION ALL
SELECT 'Active Agents', COUNT(*), 'Count'
FROM Agents WHERE Status = 'Active'
UNION ALL
SELECT 'Active Employees', COUNT(*), 'Count'
FROM Employee WHERE State = 'Active'
UNION ALL
SELECT 'Total Products', COUNT(*), 'Count'
FROM Products
UNION ALL
SELECT 'Available Products', COUNT(*), 'Count'
FROM Products WHERE Status = 'Available'
UNION ALL
SELECT 'Total Sales Records', COUNT(*), 'Count'
FROM Sales
UNION ALL
SELECT 'Total Sales Revenue', SUM(TotalAmount), 'MYR'
FROM Sales
UNION ALL
SELECT 'Total Commission Paid', SUM(CommissionAmount), 'MYR'
FROM Commission
UNION ALL
SELECT 'Active Campaigns', COUNT(*), 'Count'
FROM Campaign WHERE EndDate >= GETDATE()
UNION ALL
SELECT 'Total Feedback', COUNT(*), 'Count'
FROM Feedback
UNION ALL
SELECT 'Average Rating', AVG(CAST(Rating AS FLOAT)), 'Stars'
FROM Feedback
UNION ALL
SELECT 'Total Activities Logged', COUNT(*), 'Count'
FROM ActivityLog;
GO
--Select* From DBA_DatabaseStats

-- View 4: Data Integrity Check View (Identify Data Issues) 
Create view DBA_DataIntegrityCheck as
Select 
    'Sales without Commission' AS IssueType,
    COUNT(*) AS RecordCount,
    'Check Commission table' AS Recommendation
from Sales s
LEFT JOIN Commission c ON s.SalesID = c.SalesID
where c.CommissionID IS NULL
Union ALL
Select 
    'Products without Stock',
    COUNT(*),
    'Check StockIn records'
FROM Products p
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
WHERE st.StockInID IS NULL
UNION ALL
SELECT 
    'Users without Activity',
    COUNT(*),
    'Check ActivityLog'
FROM [User] u
LEFT JOIN ActivityLog al ON u.UserID = al.UserID
WHERE al.ActivityID IS NULL
    AND u.CreatedAt < DATEADD(DAY, -7, GETDATE())
UNION ALL
SELECT 
    'Inactive Agents with Recent Sales',
    COUNT(DISTINCT a.AgentID),
    'Review Agent Status'
FROM Agents a
INNER JOIN Sales s ON a.AgentID = s.AgentID
WHERE a.Status = 'Inactive'
    AND s.SalesDate >= DATEADD(DAY, -30, GETDATE());
GO
--Select* from DBA_DataIntegrityCheck

-- View 5: Data Integrity Check part 2? (check whether got foreign key)
CREATE VIEW DBA_ForeignKeyOverview AS
SELECT
    fk.name AS ForeignKeyName,
    s1.name AS ParentSchema,
    t1.name AS ParentTable,
    s2.name AS ReferencedSchema,
    t2.name AS ReferencedTable
FROM sys.foreign_keys fk
JOIN sys.tables t1 ON fk.parent_object_id = t1.object_id
JOIN sys.schemas s1 ON t1.schema_id = s1.schema_id
JOIN sys.tables t2 ON fk.referenced_object_id = t2.object_id
JOIN sys.schemas s2 ON t2.schema_id = s2.schema_id;
GO
Select* from DBA_ForeignKeyOverview

-------------------- Audit Team ---------------------

-- View 1: Sales Audit Trail (Track Sales Transaction) 

Create VIEW Audit_SalesTransactions AS
SELECT 
    s.SalesID,
    s.SalesDate,
    s.AgentID,
    a.AgentType,
    u.Name AS AgentName,
    s.TotalAmount,
    s.Region,  
    c.CommissionAmount,
    c.CommissionRate
FROM Sales s
LEFT JOIN Agents a ON s.AgentID = a.AgentID
LEFT JOIN [User] u ON a.AgentID = u.UserID
LEFT JOIN Commission c ON s.SalesID = c.SalesID;
GO
-- Select* from Audit_SalesTransactions

-- View 2: User Access Audit (Review User Access) 
CREATE VIEW Audit_UserAccess as
SELECT 
    u.UserID,
    u.Username,
    u.UserType,
    u.Name,
    u.CreatedAt AS AccountCreated,
    COUNT(al.ActivityID) AS TotalActivities,
    MIN(al.DoneAt) AS FirstActivity,
    MAX(al.DoneAt) AS LastActivity,
    DATEDIFF(DAY, MAX(al.DoneAt), GETDATE()) AS DaysSinceLastActivity,
    CASE 
        WHEN DATEDIFF(DAY, MAX(al.DoneAt), GETDATE()) > 90 THEN 'Inactive'
        WHEN DATEDIFF(DAY, MAX(al.DoneAt), GETDATE()) > 30 THEN 'Low Activity'
        ELSE 'Active'
    END AS ActivityStatus
FROM [User] u
LEFT JOIN ActivityLog al ON u.UserID = al.UserID
GROUP BY u.UserID, u.Username, u.UserType, u.Name, u.CreatedAt;
GO
--SELECT* FROM Audit_UserAccess

-- View 3: Financial Audit Summary (Financial Reporting / Commission) 
CREATE VIEW Audit_FinancialSummary AS
SELECT 
    YEAR(s.SalesDate) AS FiscalYear,
    MONTH(s.SalesDate) AS FiscalMonth,
    a.AgentType,
    s.Region,
    COUNT(DISTINCT s.SalesID) AS TotalTransactions,
    SUM(s.TotalAmount) AS TotalSalesRevenue,
    SUM(c.CommissionAmount) AS TotalCommissionPaid,
    SUM(s.TotalAmount) - SUM(c.CommissionAmount) AS NetRevenue
FROM Sales s
LEFT JOIN Agents a ON s.AgentID = a.AgentID
LEFT JOIN Commission c ON s.SalesID = c.SalesID
GROUP BY YEAR(s.SalesDate), MONTH(s.SalesDate), a.AgentType, s.Region;
GO
-- Select* from Audit_FinancialSummary

-------------------- Supply Chain Department ---------------------

--View 1: Check stock flow and product availability 
CREATE VIEW SC_ProductStockOverview AS
SELECT
    p.ProductID,
    p.Name AS ProductName,
    p.Status,
    s.Company AS SupplierCompany,
    ISNULL(SUM(st.Quantity), 0) AS TotalStockIn,
    ISNULL(SUM(st.TotalCost), 0) AS TotalStockCost,
    MIN(st.StockInDate) AS FirstStockInDate,
    MAX(st.StockInDate) AS LastStockInDate
FROM Products p
JOIN Supplier s ON p.SupplierID = s.SupplierID
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
GROUP BY
    p.ProductID, p.Name, p.Status, s.Company;
GO
Select* from SC_ProductStockOverview

--View 2: Evaluate supplier performance based on sales and count of 
CREATE VIEW SC_SupplierPerformance AS
SELECT
    sup.SupplierID,
    sup.Company AS SupplierCompany,
    COUNT(DISTINCT p.ProductID) AS TotalProductsSupplied,
    ISNULL(SUM(st.Quantity), 0) AS TotalStockSupplied,
    ISNULL(SUM(si.Quantity), 0) AS TotalUnitsSold,
    ISNULL(SUM(si.Subtotal), 0) AS TotalSalesRevenue
FROM Supplier sup
LEFT JOIN Products p ON sup.SupplierID = p.SupplierID
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID
LEFT JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
GROUP BY
    sup.SupplierID, sup.Company;
GO
Select* from SC_SupplierPerformance

--View 3: Track product flow 
Create VIEW SC_ProductMovement AS
SELECT
    p.ProductID,
    p.Name AS ProductName,
    sup.Company AS SupplierCompany,
    ISNULL(SUM(st.Quantity), 0) AS StockReceived,
    ISNULL(SUM(si.Quantity), 0) AS UnitsSold,
    ISNULL(SUM(st.Quantity), 0) - ISNULL(SUM(si.Quantity), 0) AS EstimatedBalance
FROM Products p
JOIN Supplier sup ON p.SupplierID = sup.SupplierID
LEFT JOIN StockIn st ON p.ProductID = st.ProductID
LEFT JOIN PromotionProduct pp ON p.ProductID = pp.ProductID
LEFT JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
GROUP BY
    p.ProductID, p.Name, sup.Company;
GO
Select* from SC_ProductMovement


