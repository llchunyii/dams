USE master;
GO

-- Prevent Concurrent Sessions
CREATE OR ALTER TRIGGER trg_login_connection_limit
ON ALL SERVER
FOR LOGON
AS
BEGIN
    IF IS_SRVROLEMEMBER('sysadmin', ORIGINAL_LOGIN()) = 0
    BEGIN
        DECLARE @ConnectionCount INT;

        -- Count all current user sessions
        SELECT @ConnectionCount = COUNT(*)
        FROM sys.dm_exec_sessions
        WHERE is_user_process = 1
          AND original_login_name = ORIGINAL_LOGIN();

        -- Block if limit exceeded
        IF @ConnectionCount > 3
        BEGIN
			RAISERROR('Maximum concurrent connections exceeded. Please close other sessions.', 16, 1);
            ROLLBACK;
        END
    END
END; 
GO

-- Restrict login times (business hours only)
CREATE OR ALTER TRIGGER trg_login_times_limit
ON ALL SERVER
FOR LOGON
AS
BEGIN
    IF IS_SRVROLEMEMBER('sysadmin', ORIGINAL_LOGIN()) = 0
    BEGIN
		DECLARE @CurrentHour INT = DATEPART(HOUR, GETDATE());
        DECLARE @CurrentDay INT = DATEPART(WEEKDAY, GETDATE());
        
        -- Block logins outside 8AM-6PM, Monday-Friday
        IF @CurrentDay IN (1, 7) OR @CurrentHour < 8 OR @CurrentHour >= 18
        BEGIN
            RAISERROR('Database access is restricted to business hours (Mon-Fri, 8AM-6PM)', 16, 1);
            ROLLBACK;
        END
	END
END; 
GO
     