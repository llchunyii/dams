USE DAMS;
GO


ALTER SCHEMA AuditorProc TRANSFER dbo.ViewServerAuditLogs;