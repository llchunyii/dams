USE DAMS;
GO

CREATE SCHEMA AdminProc;

GO

ALTER SCHEMA AdminProc TRANSFER dbo.RegisterUserWithRole;
