USE DAMS;
GO

-- Modify User Table to Add Salt Column
ALTER TABLE [User]
ALTER COLUMN Password VARBINARY(64) NOT NULL;

ALTER TABLE [User]
ADD PasswordSalt VARBINARY(16) NULL;
GO

-- Update Existing Users 
EXEC UpdateUserPassword @UserID = '1', @Password = 'Pass@123';
EXEC UpdateUserPassword @UserID = '2', @Password = 'Pass@781';
EXEC UpdateUserPassword @UserID = '3', @Password = 'Pass@513';
EXEC UpdateUserPassword @UserID = '4', @Password = 'Pass@152';
EXEC UpdateUserPassword @UserID = '5', @Password = 'Pass@183';
EXEC UpdateUserPassword @UserID = '6', @Password = 'Pass@223';
EXEC UpdateUserPassword @UserID = '7', @Password = 'Pass@523';
EXEC UpdateUserPassword @UserID = '8', @Password = 'Pass@120';
EXEC UpdateUserPassword @UserID = '9', @Password = 'Pass@022';
EXEC UpdateUserPassword @UserID = '10', @Password = 'Pass@520';
EXEC UpdateUserPassword @UserID = '11', @Password = 'Pass@212';
EXEC UpdateUserPassword @UserID = '12', @Password = 'Pass@555';
EXEC UpdateUserPassword @UserID = '13', @Password = 'Pass@262';
EXEC UpdateUserPassword @UserID = '14', @Password = 'Pass@115';
EXEC UpdateUserPassword @UserID = '15', @Password = 'Pass@132';
GO