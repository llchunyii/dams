USE DAMS;
GO

EXEC ViewServerAuditLogs;
