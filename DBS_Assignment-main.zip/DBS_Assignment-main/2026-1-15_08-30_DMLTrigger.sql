USE DAMS;
GO

-- Table to store stock quantities 
CREATE TABLE Inventory (
    InventoryID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL UNIQUE,
    QuantityOnHand INT NOT NULL DEFAULT 0,
    LastUpdated DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Inventory_Product FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    CONSTRAINT CK_Inventory_Quantity CHECK (QuantityOnHand >= 0)
);
GO

-- Initialize inventory from existing StockIn data
INSERT INTO Inventory (ProductID, QuantityOnHand, LastUpdated)
SELECT 
    ProductID, 
    SUM(Quantity) as TotalStock,
    GETDATE()
FROM StockIn
GROUP BY ProductID;
GO


-- TRIGGER: Auto-update Inventory on Stock In 
CREATE OR ALTER TRIGGER trg_StockIn_UpdateInventory
ON StockIn
AFTER INSERT
AS
BEGIN   
    BEGIN TRY
        -- Update existing inventory records
        UPDATE inv
        SET 
			inv.QuantityOnHand = inv.QuantityOnHand + i.Quantity,
            inv.LastUpdated = GETDATE()
        FROM Inventory inv
        INNER JOIN inserted i ON inv.ProductID = i.ProductID;
        
        -- Create inventory records for new products
        INSERT INTO Inventory (ProductID, QuantityOnHand, LastUpdated)
        SELECT i.ProductID, i.Quantity, GETDATE()
        FROM inserted i
        WHERE NOT EXISTS (SELECT 1 FROM Inventory WHERE ProductID = i.ProductID);        

        -- Log user activity 			
		DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
		INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
		VALUES (@UserID,'Restock product', GETDATE());
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        ROLLBACK TRANSACTION;
    END CATCH
END
GO

-- TRIGGER: Auto-update Inventory on Stock In On UPDATE
CREATE OR ALTER TRIGGER trg_StockIn_UpdateInventory_OnUpdate
ON StockIn
AFTER UPDATE
AS
BEGIN
    BEGIN TRY
		-- if Quantity changed
        IF EXISTS (
            SELECT 1
            FROM inserted i
            INNER JOIN deleted d ON i.StockInID = d.StockInID
            WHERE i.Quantity != d.Quantity
        )
		BEGIN
			;WITH diff AS (
				SELECT i.ProductID,
					   i.Quantity - d.Quantity AS QtyDiff
				FROM inserted i
				INNER JOIN deleted d ON i.StockInID = d.StockInID
				WHERE i.Quantity != d.Quantity
			)
			-- Modify inventory by the difference
			UPDATE inv
			SET inv.QuantityOnHand = inv.QuantityOnHand + diff.QtyDiff,
				inv.LastUpdated = GETDATE()
			FROM dbo.Inventory inv
			INNER JOIN diff ON inv.ProductID = diff.ProductID;

			-- Case where product didn't exist in Inventory yet
			INSERT INTO Inventory (ProductID, QuantityOnHand, LastUpdated)
			SELECT i.ProductID, i.Quantity, GETDATE()
			FROM inserted i
			WHERE NOT EXISTS (SELECT 1 FROM dbo.Inventory WHERE ProductID = i.ProductID);

			-- Log user activity 			
			DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
			INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
			VALUES (@UserID,'Modify Stock In Quantity', GETDATE());
		END
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        ROLLBACK TRANSACTION;
    END CATCH
END;
GO

-- TRIGGER: Prevent Delete Stock In
CREATE OR ALTER TRIGGER trg_StockIn_PreventDeletion
ON StockIn
INSTEAD OF DELETE
AS
BEGIN
    RAISERROR('Cannot delete stock-in records.', 16, 1);
    ROLLBACK;
END
GO


-- TRIGGER: Prevent Delete Inventory
CREATE OR ALTER TRIGGER trg_Inventory_PreventDeletion
ON Inventory
INSTEAD OF DELETE
AS
BEGIN
	RAISERROR('Cannot delete inventory records. Set QuantityOnHand to 0 instead.', 16, 1);
	ROLLBACK;
END
GO

-- TRIGGER: Auto-update Product Available Status  
CREATE OR ALTER TRIGGER trg_Inventory_UpdateProductsStatus
ON Inventory
AFTER UPDATE
AS
BEGIN
    UPDATE p
	SET p.Status = CASE 
					WHEN i.QuantityOnHand < 1 THEN 'Unavailable' 
					ELSE 'Available' 
				   END
    FROM Products p
    INNER JOIN inserted i ON p.ProductID = i.ProductID
END;
GO


-- TRIGGER: Validate and Update Inventory for Sales 
CREATE OR ALTER TRIGGER trg_SalesItem_InventoryManagement
ON SalesItem
AFTER INSERT
AS
BEGIN
	-- 1. Validate Available Stock '(aggregate by ProductID)
	IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN PromotionProduct pp ON pp.PromotionProductID = i.PromotionProductID
        JOIN Inventory inv ON inv.ProductID = pp.ProductID
        GROUP BY pp.ProductID
        HAVING SUM(i.Quantity) > inv.QuantityOnHand
    )
    BEGIN
        RAISERROR('Insufficient stock available for one or more items in the sale.', 16, 1);
        ROLLBACK TRANSACTION;
		RETURN;
    END

	-- 2. Auto-update Inventory 
	UPDATE inv
    SET 
		inv.QuantityOnHand = inv.QuantityOnHand - s.SoldQty,
        inv.LastUpdated = GETDATE()
    FROM Inventory inv
    JOIN (
        SELECT pp.ProductID, SUM(i.Quantity) AS SoldQty
        FROM inserted i
        JOIN PromotionProduct pp ON pp.PromotionProductID = i.PromotionProductID
        GROUP BY pp.ProductID
    ) s
    ON s.ProductID = inv.ProductID;

	-- Log user activity 			
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
	INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
	VALUES (@UserID,'Add Sales Product Item', GETDATE());
END;
GO  

-- TRIGGER: Block Update and Delete on Sales Item
CREATE OR ALTER TRIGGER trg_SalesItem_PreventUpdateDelete
ON SalesItem
INSTEAD OF UPDATE, DELETE
AS
BEGIN
    RAISERROR('Sales are immutable. Cannot modify or detele sales items after recording.', 16, 1);
    ROLLBACK;
END
GO


-- TRIGGER: Delete Restriction on Sales with Sales Item
CREATE OR ALTER TRIGGER trg_Sales_DeletePrevention
ON Sales
INSTEAD OF DELETE
AS
BEGIN
	-- Check if any sales have associated items or commission
    IF EXISTS (
        SELECT 1 
        FROM deleted d
        WHERE EXISTS (SELECT 1 FROM SalesItem WHERE SalesID = d.SalesID)
           OR EXISTS (SELECT 1 FROM Commission WHERE SalesID = d.SalesID)
    )

	BEGIN            
		RAISERROR('Cannot delete sales records with items or commission.', 16, 1);
		ROLLBACK TRANSACTION;
		RETURN;
	END
        
	-- Allow deletion of empty sales records (no items/commission)
	DELETE FROM Sales
	WHERE SalesID IN (SELECT SalesID FROM deleted);
	
    DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID,'Discard empty sales', GETDATE());
END
GO

-- TRIGGER: Block Update Sales 
CREATE OR ALTER TRIGGER trg_Sales_PreventUpdate
ON Sales
INSTEAD OF UPDATE
AS
BEGIN
    RAISERROR('Cannot update sales records.', 16, 1);
    ROLLBACK;
END
GO


-- TRIGGER: Prevent Deletion of Agents with Sales
CREATE OR ALTER TRIGGER trg_Agents_PreventDeletion
ON Agents
AFTER DELETE
AS
BEGIN
	-- Check if any deleted agents have sales records
	IF EXISTS (
		SELECT 1 
		FROM deleted d
		INNER JOIN Sales s ON d.AgentID = s.AgentID
	)
	BEGIN
		RAISERROR('Cannot delete agent with existing sales records. Set Status to Inactive instead.', 16, 1);
		ROLLBACK TRANSACTION;
		RETURN;
	END
	
	-- Log user activity 			
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
	INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
	VALUES (@UserID,'Remove Agent', GETDATE());
END
GO


-- TRIGGER: Protect Products in Active Campaigns
CREATE OR ALTER TRIGGER trg_Products_PreventDeletion
ON Products
INSTEAD OF DELETE
AS
BEGIN
    -- Check: Product in active promotion
    IF EXISTS (
        SELECT 1
        FROM deleted d
        INNER JOIN PromotionProduct pp ON d.ProductID = pp.ProductID
        INNER JOIN Promotion p ON pp.PromotionID = p.PromotionID
        INNER JOIN Campaign c ON p.CampaignID = c.CampaignID
        WHERE GETDATE() BETWEEN c.StartDate AND c.EndDate -- Active campaign
    )
    BEGIN          
        RAISERROR('Cannot delete product as it is currently in active campaign. Please remove from promotion first or wait until campaign ends.', 16, 1);
		ROLLBACK TRANSACTION;
        RETURN;
    END
    
	-- Check: Products in ANY promotion (past/future)
	IF EXISTS (
		SELECT 1
		FROM deleted d
		INNER JOIN PromotionProduct pp ON d.ProductID = pp.ProductID
    )
    BEGIN         
        RAISERROR('Cannot delete product with promotion history.', 16, 1);
		ROLLBACK TRANSACTION;
        RETURN;
    END
        
    -- Check: Products with sales history        
    IF EXISTS (
        SELECT 1
        FROM deleted d
        INNER JOIN PromotionProduct pp ON d.ProductID = pp.ProductID
        INNER JOIN SalesItem si ON pp.PromotionProductID = si.PromotionProductID
    )
    BEGIN
        RAISERROR('Cannot delete product with sales history.', 16, 1);
		ROLLBACK TRANSACTION;
        RETURN;
    END
        
    -- Check: Products in inventory        
    IF EXISTS (
        SELECT 1
        FROM deleted d
        INNER JOIN Inventory inv ON d.ProductID = inv.ProductID
        WHERE inv.QuantityOnHand > 0
    )
    BEGIN  
        RAISERROR('Cannot delete product with inventory. Clear inventory first or set Status=''Unavailable''.', 16, 1);
        ROLLBACK TRANSACTION;
		RETURN;
    END

    -- Safe to delete - no active promotions
    DELETE p
    FROM Products p
    JOIN deleted d ON d.ProductID = p.ProductID;

	-- Log user activity 			
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);
	INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
	VALUES (@UserID,'Remove Product', GETDATE());
END;
GO



-- Auto-Update ActivityLog for User Actions

--Stored Procedure for track current user ID
-- sp to set current user
CREATE OR ALTER PROCEDURE SetCurrentUserContext
    @UserID INT
AS
BEGIN
    EXEC sys.sp_set_session_context @key=N'UserID', @value=@UserID;
END;
GO

-- sp to log login of current user 
CREATE OR ALTER PROCEDURE LogUserLogin
    @UserID INT
AS
BEGIN
    -- Set context for this session
    EXEC SetCurrentUserContext @UserID = @UserID;

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, 'User Login', GETDATE());
END;
GO

-- sp to log logout of current user 
CREATE OR ALTER PROCEDURE LogUserLogout
AS
BEGIN
    DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, 'User Logout', GETDATE());

    -- clear user context
    EXEC sys.sp_set_session_context @key=N'UserID', @value=NULL;
END;
GO



-- TRIGGER: New Sales Log
CREATE OR ALTER TRIGGER trg_Sales_ActivityLog
ON Sales
AFTER INSERT
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, 'Register Sales', GETDATE());
END;
GO

-- TRIGGER: Feedback Log
CREATE OR ALTER TRIGGER trg_Feedback_ActivityLog
ON Feedback
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    DECLARE @Action NVARCHAR(100) =
        CASE
            WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'Edit Feedback'
             WHEN EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted) THEN 'Submit Feedback'
            ELSE 'Delete Feedback'
        END;

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, @Action, GETDATE());
END;
GO

-- TRIGGER: Password and Profile Log
CREATE TRIGGER trg_User_ActivityLog
ON [User]
AFTER UPDATE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

	-- Change Password 
	IF UPDATE(Password)
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Change Password', GETDATE());
    END

    -- Edit Profile 
    IF UPDATE(Username) OR UPDATE(Name) OR UPDATE(Email) OR UPDATE(Phone) OR UPDATE(Address)
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Profile', GETDATE());
    END
END;
GO

-- TRIGGER: Agent Information Log
CREATE TRIGGER trg_Agents_ActivityLog
ON Agents
AFTER UPDATE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

	-- Edit Agent Profile 
    IF UPDATE(AgentType) 
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Agent Type', GETDATE());
    END

	-- Edit Agent Status 
    IF UPDATE(Status) 
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Agent Active Status', GETDATE());
    END
END;
GO

-- TRIGGER: Employee Information Log
CREATE TRIGGER trg_Employee_ActivityLog
ON Employee
AFTER UPDATE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

	-- Edit Employee Profile 
    IF UPDATE(DepartmentID) OR UPDATE(JobTitle) 
    BEGIN

        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Employee Detail', GETDATE());
    END

	-- Edit Employee Status 
    IF UPDATE(State) 
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Employee State', GETDATE());
    END
END;
GO

-- TRIGGER: Agent Log
CREATE TRIGGER trg_UserAgent_ActivityLog
ON Agents
AFTER INSERT
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, 'Add New Agent', GETDATE());
END;
GO

-- TRIGGER: Employee Log
CREATE TRIGGER trg_UserEmployee_ActivityLog
ON Employee
AFTER INSERT
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, 'Add New Employee', GETDATE());
END;
GO

-- TRIGGER: Product Log
CREATE OR ALTER TRIGGER trg_Products_ActivityLog
ON Products
AFTER INSERT, UPDATE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

	-- INSERT
    IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Add New Products', GETDATE());
        RETURN;
    END

    -- UPDATE: ignore updates that only change Status (system rule)
    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN deleted d ON d.ProductID = i.ProductID
        WHERE (ISNULL(i.Name,'') <> ISNULL(d.Name,'')
            OR ISNULL(i.Description,'') <> ISNULL(d.Description,'')
            OR ISNULL(i.Price,0) <> ISNULL(d.Price,0))
			OR ISNULL(i.SupplierID,0) <> ISNULL(d.SupplierID,0)
    )
    BEGIN
        INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
        VALUES (@UserID, 'Edit Product Detail', GETDATE());
    END
END;
GO

-- TRIGGER: Department Log
CREATE OR ALTER TRIGGER trg_Department_ActivityLog
ON Department
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	DECLARE @UserID INT = TRY_CAST(SESSION_CONTEXT(N'UserID') AS INT);

    DECLARE @Action NVARCHAR(100) =
        CASE
            WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'Edit Department'
            WHEN EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted) THEN 'Add New Department'
            ELSE 'Remove Department'
        END;

    INSERT INTO ActivityLog (UserID, ActivityType, DoneAt)
    VALUES (@UserID, @Action, GETDATE());
END;
GO
